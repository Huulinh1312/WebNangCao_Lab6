import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Link, useParams } from "react-router-dom";
import { useState } from "react";
import "./App.css";

const products = [
  { id: 1, name: "Iphone 15 Promax", image: "/images/product1.jpg", price: 29000000, description: " iPhone 15 Pro Max với thiết kế Titanium siêu nhẹ, chip A17 Pro mạnh mẽ, hệ thống camera Pro với ống kính Telephoto 5x, màn hình Super Retina XDR 6.7 inch và cổng USB-C tiện lợi." },
  { id: 2, name: "Iphone 15 Pro", image: "/images/product2.jpg", price: 25000000, description: " iPhone 15 Pro sở hữu khung viền Titanium, chip A17 Pro hiệu năng cao, cụm 3 camera với khả năng quay video 4K ProRes, màn hình Super Retina XDR 6.1 inch và cổng USB-C mới." },
  { id: 3, name: "Iphone 15", image: "/images/product3.jpg", price: 22000000, description: " iPhone 15 có thiết kế viền nhôm với mặt kính màu, Dynamic Island thông minh, chip A16 Bionic mạnh mẽ, camera chính 48MP hỗ trợ zoom quang học 2x và cổng USB-C tiện lợi." },
];

function ProductList({ addToCart }) {
  return (
    <div>
      <h1>Danh sách sản phẩm</h1>
      <Link to="/cart" className="cart-button">Giỏ hàng</Link>
      <div className="product-list">
        {products.map((product) => (
          <div key={product.id} className="product-item">
            <img src={product.image} alt={product.name} width="100" />
            <div className="product-info">
              <h3>{product.name} - {product.price} VND</h3>
              <Link to={`/product/${product.id}`}><button>Xem chi tiết</button></Link>
              <button onClick={() => addToCart(product)}>Thêm vào giỏ</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProductDetail({ addToCart }) {
  const { id } = useParams();
  const product = products.find((p) => p.id === parseInt(id));

  return (
    <div className="product-detail-container">
      <div className="product-detail-card">
        <img src={product.image} alt={product.name} className="product-detail-image" />
        <div className="product-detail-info">
          <h1>{product.name}</h1>
          <p className="product-price"><strong>Giá:</strong> {product.price.toLocaleString()} VND</p>
          <p className="product-description"><strong>Mô tả:</strong> {product.description}</p>
          <button onClick={() => addToCart(product)}>Thêm vào giỏ</button>
          <Link to="/" className="back-button">⬅ Quay lại danh sách</Link>
        </div>
      </div>
    </div>
  );
}


function Cart({ cart, removeFromCart }) {
  return (
    <div>
      <h1>Giỏ hàng</h1>
      {cart.length === 0 ? (
        <p>Giỏ hàng trống</p>
      ) : (
        cart.map((item, index) => (
          <div key={index} className="cart-item">
            <img src={item.image} alt={item.name} width="100" />
            <p>{item.name} - {item.price} VND</p>
            <button onClick={() => removeFromCart(index)}>🗑 Xóa</button>
            <button className="buy-button">🛒 Mua</button>
          </div>
        ))
      )}
      <br />
      <Link to="/"className="back-button">Quay lại danh sách</Link>
    </div>
  );
}

export default function App() {
  const [cart, setCart] = useState([]);
  const [message, setMessage] = useState(""); // Trạng thái cho thông báo

  const addToCart = (product) => {
    setCart([...cart, product]);
    setMessage(`${product.name} đã được thêm vào giỏ hàng!`);

    // Tự động ẩn thông báo sau 2 giây
    setTimeout(() => {
      setMessage("");
    }, 2000);
  };

  const removeFromCart = (index) => {
    setCart(cart.filter((_, i) => i !== index));
  };

  return (
    <Router>
      <div className="notification-container">
        {message && <div className="notification">{message}</div>}
      </div>
      <Routes>
        <Route path="/" element={<ProductList addToCart={addToCart} />} />
        <Route path="/product/:id" element={<ProductDetail addToCart={addToCart} />} />
        <Route path="/cart" element={<Cart cart={cart} removeFromCart={removeFromCart} />} />
      </Routes>
    </Router>
  );
}
